using Microsoft.EntityFrameworkCore;
using UniversityApi.Data;
using UniversityApi.Interfaces;
using UniversityApi.Models;

namespace UniversityApi.Repositories
{
    public class InstructorRepository : IInstructor
    {
        private readonly UniversityContext _context;

        public InstructorRepository(UniversityContext context)
        {
            _context = context;
        }

        public bool AddInstructor(Instructor instructor)
        {
            var exists = _context.Instructors
                .Any(i => i.Name == instructor.Name);

            if (exists)
                return false;

            _context.Instructors.Add(instructor);
            _context.SaveChanges();
            return true;
        }

        public IEnumerable<Instructor> GetInstructorsWithCourseCountAbove(int count)
        {
            return _context.Instructors
                .Include(i => i.InstructorCourses)
                .Where(i => i.InstructorCourses.Count > count)
                .ToList();
        }

        public IEnumerable<Instructor> GetInstructorsWithMostEnrollments()
        {
            var instructorEnrollments = _context.Instructors
                .Select(i => new
                {
                    Instructor = i,
                    EnrollmentCount = i.InstructorCourses
                        .SelectMany(ic => ic.Course.Enrollments)
                        .Count()
                })
                .ToList();

            int max = instructorEnrollments.Max(x => x.EnrollmentCount);

            return instructorEnrollments
                .Where(x => x.EnrollmentCount == max)
                .Select(x => x.Instructor)
                .ToList();
        }
    }
}