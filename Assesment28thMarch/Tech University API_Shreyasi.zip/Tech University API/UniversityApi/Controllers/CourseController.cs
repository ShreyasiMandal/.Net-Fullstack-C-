using Microsoft.AspNetCore.Mvc;
using UniversityApi.Interfaces;
using UniversityApi.Models;

namespace UniversityApi.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CourseController : ControllerBase
    {
        private readonly ICourse _courseRepo;

        public CourseController(ICourse courseRepo)
        {
            _courseRepo = courseRepo;
        }

        [HttpPut("UpdateCourse")]
        public IActionResult UpdateCourse([FromBody] Course course)
        {
            var result = _courseRepo.UpdateCourse(course);

            if (result)
                return Ok();
            return BadRequest();
        }

        [HttpGet("WithEnrollmentsAboveGrade/{grade}")]
        public IActionResult GetCoursesAboveGrade(int grade)
        {
            var courses = _courseRepo.GetCoursesWithEnrollmentsAboveGrade(grade);

            if (courses.Any())
                return Ok(courses);

            return NotFound("No Records Found");
        }

        [HttpGet("ByInstructorName/{instructorName}")]
        public IActionResult GetCoursesByInstructor(string instructorName)
        {
            var courses = _courseRepo.GetCoursesByInstructorName(instructorName);

            if (courses.Any())
                return Ok(courses);

            return NotFound("No Records Found");
        }
    }
}