﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
using System.Text.Json;

namespace ShipmentServiceDemo
{
    public class ShipmentWorker : BackgroundService
    {
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost"
            };

            var connection = await factory.CreateConnectionAsync();
            var channel = await connection.CreateChannelAsync();

            // Read from payment queue
            await channel.QueueDeclareAsync("payment_queue", false, false, false, null);

            // Write to shipment queue
            await channel.QueueDeclareAsync("shipment_queue", false, false, false, null);

            Console.WriteLine("ShipmentService waiting for payment...");

            var consumer = new AsyncEventingBasicConsumer(channel);

            consumer.ReceivedAsync += async (sender, ea) =>
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                var payment = JsonSerializer.Deserialize<PaymentResult>(message);

                Console.WriteLine($"Payment received for Order {payment.OrderId}");

                // Shipment Logic
                var shipment = new
                {
                    OrderId = payment.OrderId,
                    Status = "SHIPPED"
                };

                Console.WriteLine($"Order {payment.OrderId} shipped!");

                var newMessage = JsonSerializer.Serialize(shipment);
                var newBody = Encoding.UTF8.GetBytes(newMessage);

                await channel.BasicPublishAsync(
                    exchange: "",
                    routingKey: "shipment_queue",
                    body: newBody);

                await Task.CompletedTask;
            };

            await channel.BasicConsumeAsync("payment_queue", true, consumer);
        }
    }

    public class PaymentResult
    {
        public int OrderId { get; set; }
        public string Status { get; set; }
    }
}