﻿using RabbitMQ.Client;
using RabbitMQ.Client.Events;
using System.Text;
using System.Text.Json;

namespace PaymentDemo
{
    public class PaymentWorker : BackgroundService
    {
        protected override async Task ExecuteAsync(CancellationToken stoppingToken)
        {
            var factory = new ConnectionFactory()
            {
                HostName = "localhost"
            };

            var connection = await factory.CreateConnectionAsync();
            var channel = await connection.CreateChannelAsync();

            // Read from order queue
            await channel.QueueDeclareAsync("order_queue", false, false, false, null);

            // Write to payment queue
            await channel.QueueDeclareAsync("payment_queue", false, false, false, null);

            Console.WriteLine("PaymentService waiting for orders...");

            var consumer = new AsyncEventingBasicConsumer(channel);

            consumer.ReceivedAsync += async (sender, ea) =>
            {
                var body = ea.Body.ToArray();
                var message = Encoding.UTF8.GetString(body);

                var order = JsonSerializer.Deserialize<Order>(message);

                Console.WriteLine($"Processing Payment for Order {order.OrderId}");

                // Fake Payment Logic
                var paymentStatus = new
                {
                    OrderId = order.OrderId,
                    Status = "SUCCESS"
                };

                var responseMessage = JsonSerializer.Serialize(paymentStatus);
                var responseBody = Encoding.UTF8.GetBytes(responseMessage);

                await channel.BasicPublishAsync(
                    exchange: "",
                    routingKey: "payment_queue",
                    body: responseBody);

                await Task.CompletedTask;
            };

            await channel.BasicConsumeAsync("order_queue", true, consumer);
        }
    }

    public class Order
    {
        public int OrderId { get; set; }
        public double Amount { get; set; }
    }
}